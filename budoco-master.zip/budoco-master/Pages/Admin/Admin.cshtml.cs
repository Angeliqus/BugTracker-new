﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace budoco.Pages
{
    public class AdminModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
