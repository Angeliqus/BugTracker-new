BEGIN;

update db_version set db_version = 2;

COMMIT;