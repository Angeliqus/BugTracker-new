BEGIN;

update db_version set db_version = 3;

COMMIT;