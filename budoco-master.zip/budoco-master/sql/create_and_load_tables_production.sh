psql -d budoco -U postgres -f setup.sql
psql -d budoco -U postgres -f queries.sql
psql -d budoco -U postgres -f reports.sql
